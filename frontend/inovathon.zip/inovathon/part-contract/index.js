/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const PartContract = require('./lib/part-contract');

module.exports.PartContract = PartContract;
module.exports.contracts = [ PartContract ];
